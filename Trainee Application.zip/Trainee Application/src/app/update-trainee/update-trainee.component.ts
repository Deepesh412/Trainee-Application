import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MyserviceService, Trainees } from '../myservice.service';

@Component({
  selector: 'app-update-trainee',
  templateUrl: './update-trainee.component.html',
  styleUrls: ['./update-trainee.component.css']
})
export class UpdateTraineeComponent implements OnInit {
  obj1: any;
  employees: Trainees[];
  message: string;
  constructor(private myservice: MyserviceService, private router: Router) {
    this.obj1 = this.myservice.updateMethod();
  }
  onUpdate(trainee: Trainees): any {
    return this.myservice.onUpdate(trainee).subscribe(data => {
      this.message = data
    });
  }
  ngOnInit(): void {
  }

}
